from setuptools import setup, find_packages

with open('README.md', encoding="utf8") as readme_file:
    README = readme_file.read()

with open('LICENSE.md', encoding="utf8") as license_file:
    LICENSE = license_file.read()

setup_args = dict(
    name='wordslistpack',
    version='0.0.1',
    description='Python library to manage sentence or paragraph',
    long_description_content_type="text/markdown",
    long_description=README,
    license=LICENSE,
    packages=find_packages(),
    author='Subeesh Palamadathil',
    author_email='subi4020@gmail.com',
    keywords=['wordslist', 'wordslistfromparagraph', 'wordslistfromsentence'],
    url='https://github.com/Subeesh4020/',
    download_url='https://pypi.org/project/wordslistpack/'
)


if __name__ == '__main__':
    setup(**setup_args)